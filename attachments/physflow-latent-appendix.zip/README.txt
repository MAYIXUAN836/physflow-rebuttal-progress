PhysFlow appendix replacement

1. 上传 figures/latent_analysis.pdf 到 Overleaf 的 figures 目录。
2. 用 latent_representation_analysis.tex 的完整内容替换原来的 Probing Physical Reasoning through Latent Interventions 小节。
3. 保留主文档最后的 \end{document}；本片段不包含该命令。
4. 本节整合四个 panel：a 角色结构，b 六领域线性探针，c 物理干预配对预测，d 中间视觉 token 扰动。单独的旧结构分析图无需重复插入。
5. [H] 需要导言区加载 \usepackage{float}；当前论文已经加载。

已在当前 ICLR 模板编译，整节（含图注）占一页。保留原有 sec:mid_interventions 和 fig:mid_interventions 引用标签。
正文沿用通过独立审阅的版本，配图为用户接受的最新 v15；全部实验分数和指标定义保持一致。
